New oil-painted butterfly art.1024x1024 RGBA with fixed padding. Video production pending separate approval. No old video restyling.
