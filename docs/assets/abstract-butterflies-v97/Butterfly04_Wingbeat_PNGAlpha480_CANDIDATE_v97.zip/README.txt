CANDIDATE ONLY.72RGBA frames,480x480,24fps,3seconds. Native-rate24-frame real wingbeat repeated3times. Alpha edge cleanup and user approval pending. Not connected to game.
